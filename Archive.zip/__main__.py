"""An AWS Python Pulumi program"""

import pulumi
import pulumi_aws as aws
import json
import yaml
from src.pulumi_aws_vpc.config import VPCConfig
from src.pulumi_aws_vpc.vpc_resource import VPC

app_name = "pfas"
account_name = "networking-security-sandbox"
environment = "development"
aws_region = "us-east-1"
input_file_name = "vpc_config.yaml"


def config_data(account_name: str, region: str, environment: str) -> VPCConfig:
    input_path = f"{account_name}/{region}/{environment}/{input_file_name}"
    with open(input_path) as f:
        config_data = yaml.load(f, Loader=yaml.CLoader)
        aws_vpc_data = config_data.get("config", {}).get("aws_vpc")
        # print(aws_vpc_data)
        vpc_config = VPCConfig.model_validate(aws_vpc_data)
        return vpc_config

def main() -> None:
    vpc_config = config_data(account_name, aws_region, environment)
    vpc = VPC(vpc_config)


if __name__ == "__main__":
    main()