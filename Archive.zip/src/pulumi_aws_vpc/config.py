import sys
import os
import pydantic
from pydantic import ConfigDict, Field
from pydantic.networks import IPv4Address
# from enum import Enum 
from typing import List, Optional, Any
# from typing_extensions import Self
sys.path.append(os.path.abspath("pulumi_aws_python/src"))
from .utils import divide_supernet_into_subnets


class BaseModel(pydantic.BaseModel):
    model_config = ConfigDict(extra="forbid", coerce_numbers_to_str=True)


class SubnetCidr(BaseModel):
    cidr: Optional[str] = None
    cidr_num: int = 1
    size: Optional[int] | Optional[str] = None 


class Subnet(BaseModel):
    name: str
    az_id: str
    ipv4: Optional[SubnetCidr] = None
    prefix_length: Optional[int] = None
    route_table: Optional[str] = None
    tags: dict[str, str] = {}


class VPCCidr(BaseModel):
    cidr: Optional[str] = None
    size: Optional[int] = None
    subnets: List[Subnet] = []

    def get_subnets(self) -> list[Subnet]:
        print(f"self in config model named get_subnets {self}")
        auto_allocate_subnets = [subnet for subnet in self.subnets if subnet.prefix_length and not subnet.cidr]
        if auto_allocate_subnets:
            cidrs = divide_supernet_into_subnets(self.cidr,[subnet.prefix_length for subnet in auto_allocate_subnets])
            for cidr, subnet in zip(cidrs, auto_allocate_subnets):
                subnet.cidr = cidr
        return self.subnets

class VPCCidrs(BaseModel):
    ipv4: List[VPCCidr] = Field(default_factory=list)


# class Route(BaseModel):
#     destination: str
#     next_hop: str

# class RouteTable(BaseModel):
#     name: str
#     routes: list[Route] 
#     tags: dict [str, str] = {}

# class VirtualGateway(BaseModel):
#     asn: int
#     route_table: Optional[str] = None
#     tags: dict[str, str] = {}
#     vpn_connections: list[Any] = []


class InternetGateway(BaseModel):
    route_table: str
    tags: dict[str, str] = {}


class ElasticIP(BaseModel):
    name: str
    border_group: Optional[str] = Field(None, serialization_alias="network_border_group")
    public_pool: Optional[str] = Field(None, serialization_alias="public_ipv4_pool")
    customer_owned_pool: Optional[str] = Field(None, serialization_alias="customer_owned_ipv4_pool")
    ipam_pool: Optional[str] = Field(None, serialization_alias="ipam_pool_id")
    ip: Optional[IPv4Address] = Field (None, serialization_alias="address")
    tags: dict[str, str] = {}

    def dump(self) -> dict[str, Any]:
        result = self.model_dump(
            mode="json", by_alias=True, exclude=["tags","name"],exclude_none=True
            )
        return result


# class AttachmentType(str, Enum):
#     TRANSIT_GATEWAY = "transit_gateway"
#     CLOUDWAN = "cloudwan"

# class VPCAttachment(BaseModel):
#     name: str
#     type: AttachmentType 
#     subnets: list[str]
#     tgw_id: Optional[str] = None
#     core_network_id: Optional[str] = None
#     provider: Optional[str] = None
#     association_rt: Optional[str] = None
#     propagation_rts: list[str] = []
#     tags: dict[str, str] = {}



# class NATGatewayType(str, Enum):
#     PUBLIC = "public"
#     PRIVATE = "private"


# class NATGateway(BaseModel):
#     def validate_number_of_eips(self) -> Self:
#         return self
    
#     @property
#     def is_public(self) -> bool:
#         return self.type is NATGatewayType.PUBLIC


class VPCConfig(BaseModel) :
    name: str
    internet_gateway: Optional[InternetGateway] = None
    elastic_ips: list[ElasticIP] = Field(default_factory=list)
    cidrs: VPCCidrs
    subnets: list[Subnet] = []
    # route_tables: list[RouteTable]
    # nat_gateways: list[NATGateway] = []
    # attachments: list[VPCAttachment] = []
    # endpoints: [list[Any]] = []
    # dns: Any = None
    # flow_logs: list[Any] = []
    tags: dict[str,str] =   {}
    common_tags: dict[str,str] = {}

    @property
    def primary_cidr(self) -> VPCCidr:
        return self.cidrs.ipv4[0]
    
    @property
    def secondary_cidrs(self) -> list[VPCCidr] :
        if len(self.cidrs.ipv4) < 2:
            raise ValueError(f"VPC: {self.name} has only {len(self.cidrs)} CIDRs")
        return self.cidrs.ipv4[1:]


    
    # @property
    # def subnets(self) -> Iterable[subnetConfig]:
    #     for cidr in self.vpc_cidr:

    #         for subnet in cidr.subnets:
    #             yield subnet
